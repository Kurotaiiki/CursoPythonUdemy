def despedir():
    print("esto es una despedida")

class Despedida():
    def  __init__(self):
        print("adios")