def saludar():
    print("Esto es un saludo")

class Saludo():
    def  __init__(self):
        print("hola ")