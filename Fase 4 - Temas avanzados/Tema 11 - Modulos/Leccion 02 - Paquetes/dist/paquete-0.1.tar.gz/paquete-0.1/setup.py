from setuptools import  setup

setup(
    name="paquete",
    version="0.1",
    description="paquete de ejemplo",
    author="Felipe Vargas",
    author_email="pipe@ejemplo.com",
    url="http://ejemplo.com",
    scripts=[],
    packages=["paquete","paquete.adios","paquete.hola"]
)





